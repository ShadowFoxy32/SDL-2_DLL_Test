#include<Windows.h>
typedef void(__stdcall * SDL2_init)();
int main(){
	HINSTANCE SDL2 = LoadLibrary("SDL2DLLTest.dll");
	SDL2_init sdl2_init = *(SDL2_init)GetProcAddress(SDL2, "SDL2_init");
	sdl2_init();
}