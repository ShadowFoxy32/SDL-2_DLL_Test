#include<Windows.h>
#include<SDL.h>
#include<SDL_image.h>
#include<SDL_mixer.h>
#include<cstdio>
extern"C"{
	bool loop = false;
	__declspec(dllexport) void Example_init(){
		//Credit To Jardel Carvalho Link to:https://stackoverflow.com/questions/51121457/sdl-layered-rendering-system
		SDL_Window *window;
		SDL_Renderer *render;
		SDL_Texture *map; //map texture (my layer)

		window = SDL_CreateWindow("Test window", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 640, 480, 0);
		render = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
		map = SDL_CreateTexture(render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 640, 480); //Creating a texture

		/*Map is a red background stored in map texture*/
		SDL_SetRenderDrawColor(render, 255, 0, 0, 255);
		SDL_SetRenderTarget(render, map);
		SDL_RenderClear(render);
		SDL_SetRenderTarget(render, NULL);

		/*Seting the line color*/
		SDL_SetRenderDrawColor(render, 0, 255, 0, 255);

		/*Coping the map texture to the render and drawing a green line on top of this*/
		SDL_RenderCopy(render, map, NULL, NULL);
		SDL_RenderDrawLine(render, 0, 0, 640, 480);
		SDL_RenderPresent(render);
		SDL_Delay(2000);

		/*Another line*/
		SDL_RenderCopy(render, map, NULL, NULL);
		SDL_RenderDrawLine(render, 0, 480, 640, 0);
		SDL_RenderPresent(render);
		SDL_Delay(2000);

		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(render);
		SDL_Quit();
	}
	__declspec(dllexport) void DialogMessage(const char* Message, const char* Caption,UINT MessageBoxType){
		MessageBox(0, Message, Caption, MessageBoxType);
	}
	__declspec(dllexport) void Loop(){

	}
	__declspec(dllexport) void SDL2_init(){
		// Credit To GigiLabs Link To: http://gigi.nullneuron.net/gigilabs/loading-images-in-sdl2-with-sdl_image/
		SDL_Surface* src;
		SDL_Surface* srcTest;
		SDL_Surface* srcControls;
		SDL_Surface* dst;
		SDL_Rect dstrect;
		SDL_Rect dstrectTest;
		SDL_Rect dstrectControls;
		SDL_Rect srcrect;
		Mix_Music* music;
		srcrect.w = 64;
		srcrect.h = 64;
		srcrect.x = 0;
		srcrect.y = 0;
		dstrect.w = 64;
		dstrect.h = 64;
		dstrect.x = 0;
		dstrect.y = 536;
		dstrectControls.w = 800;
		dstrectControls.h = 600;
		dstrectControls.x = 0;
		dstrectControls.y = 0;
		dstrectTest.w = 64; 
		dstrectTest.h = 64;
		dstrectTest.x = 0;
		dstrectTest.y = 0;
		SDL_Init(SDL_INIT_EVERYTHING);
		Mix_Init(MIX_INIT_MP3);
		Mix_OpenAudio(44100, AUDIO_F32, 2, 4096);
		music = Mix_LoadMUS("res/55.mp3");
		Mix_VolumeMusic(50);
		Mix_PlayMusic(music, -1);
		auto Window = SDL_CreateWindow("SDL 2 DLL Example", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 600, SDL_WindowFlags::SDL_WINDOW_SHOWN);
		auto Render = SDL_CreateRenderer(Window,-1, SDL_RendererFlags::SDL_RENDERER_ACCELERATED);
		SDL_SetRenderDrawColor(Render, 58, 177, 241, 255);
		SDL_RenderClear(Render);
		SDL_Event e;
		
		src = SDL_LoadBMP("res/Test.bmp");
		//SDL_BlitSurface(src, &srcrect, dst,&dstrect);
		srcTest = SDL_LoadBMP("res/Image3.bmp");
	
		
		SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL,&dstrectTest);
		SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
		SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
		loop = true;
		
		while (loop == true){
			SDL_PollEvent(&e);
			SDL_RenderPresent(Render);
			
			if (SDL_IntersectRect(&dstrect, &dstrectTest, &srcrect) == SDL_TRUE){
				dstrect.y += dstrect.y;
				dstrect.x += dstrect.x;
			
			}
			if (SDL_GetError() == "Invalid texture"){
				MessageBox(0, "Failed To Load Texture!", "Error!", MB_ICONERROR);
			}
			if (e.type == SDL_QUIT){
				loop = false;
				//SDL_FreeSurface(src);
				SDL_DestroyWindow(Window);

			}
			if (e.type == SDL_KEYDOWN){
				switch (e.key.keysym.sym){
				case SDLK_RIGHT:
					srcControls = SDL_LoadBMP("res/controls.bmp");
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					Sleep(2);
					dstrect.x += 1;
					break;
				case SDLK_LEFT:
					srcControls = SDL_LoadBMP("res/controls.bmp");
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
		
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					Sleep(2);
					dstrect.x -= 1;
					break;
				case SDLK_DOWN:
					SDL_SetRenderDrawColor(Render, 0, 0, 0, 255);
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
				
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					Sleep(2);
					dstrect.y += 1;
					break;
				case SDLK_UP:
				
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					Sleep(2);
					dstrect.y -= 1;
					break;
				case SDLK_w:
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					dstrect.y -= 2;
					break;
				case SDLK_s:
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderClear(Render);

				
					
					SDL_RenderPresent(Render);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					//SDL_RenderPresent(Render);
				

					dstrect.y += 2;
					break;
				case SDLK_d:
					srcControls = SDL_LoadBMP("res/controls.bmp");
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					dstrect.x += 2;
					break;
				case SDLK_a:
					srcControls = SDL_LoadBMP("res/controls.bmp");
					SDL_RenderCopy(Render, SDL_CreateTexture(Render, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64), NULL, &srcrect);
					SDL_RenderClear(Render);

					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcTest), NULL, &dstrectTest);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, src), NULL, &dstrect);
					SDL_RenderPresent(Render);

					dstrect.x -= 2;
					break;
				case SDLK_e:
					MessageBox(0, SDL_GetError(), "Error!", MB_ICONERROR);	
					break;
				case SDLK_c:
					srcControls = SDL_LoadBMP("res/controls.bmp");
					SDL_RenderClear(Render);
					SDL_RenderCopy(Render, SDL_CreateTextureFromSurface(Render, srcControls), NULL, &dstrectControls);
					break;
				case SDLK_x:
					
					printf("%i", dstrect.y);
					break;
				}
			

			
			}
		}
		
	}
	



	__declspec(dllexport) void Log(){
		MessageBox(0, "Method Not Implemented", "Error!", MB_ICONERROR);
	}
	__declspec(dllexport) void Imgui(){
		MessageBox(0, "Method Not Implemented", "Error!", MB_ICONERROR);
	}
	__declspec(dllexport) void Log_SDL2_Error(){
		MessageBox(0, "Method Not Implemented", "Error!", MB_ICONERROR);
	}

	__declspec(dllexport) void Imgui_SDL2(){
		MessageBox(0, "Method Not Implemented", "Error!", MB_ICONERROR);
	}
	__declspec(dllexport) void SDL2_Other_init(){
		
		MessageBox(0, "Method Not Implemented", "Error!", MB_ICONERROR);
	}



	__declspec(dllexport) void SDL2_Mixer_PlayWave(){

	}
	
	__declspec(dllexport) void SDL2_Image_DrawImage(){

	}
	
}